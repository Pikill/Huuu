#!/usr/bin/env node
import fs from 'fs/promises';
import path from 'path';
import { launchPersistentContext } from 'cloakbrowser';

const ROOT = process.cwd();
const API = 'https://doppel.fun/api';
const COOKIE_FILE = path.join(ROOT, 'dopcbcookies.txt');
const CACHE_FILE = path.join(ROOT, 'quest_cache.json');
const LOG_FILE = path.join(ROOT, 'quest_results.jsonl');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36';
const LIMIT = Number(process.env.LIMIT || process.argv.find(a => a.startsWith('--limit='))?.split('=')[1] || 0);
const CONCURRENCY = Math.min(5, Math.max(1, Number(process.env.CONCURRENCY || process.argv.find(a => a.startsWith('--concurrency='))?.split('=')[1] || 1)));
const ONCE = process.argv.includes('--once');
const FAST = process.argv.includes('--fast');

const PROXIES_FILE = path.join(ROOT, 'proxies.txt');
const PROXY_CHECK_TIMEOUT = 15_000;
const PROXY_MAX_RETRIES = 5;
const IP_CHECK_URLS = ['https://api.ipify.org?format=json','https://ifconfig.me/ip','https://api.my-ip.io/ip.json'];

function loadProxies() {
  return fs.readFile(PROXIES_FILE, 'utf8')
    .then(txt => txt.split(/\r?\n/).map(l => l.trim()).filter(Boolean).filter(l => !l.startsWith('#')))
    .then(lines => {
      if (!lines.length) throw new Error('FATAL: proxies.txt is empty.');
      console.log(`[PROXY] Loaded ${lines.length} proxy line(s) from proxies.txt`);
      return lines;
    });
}
function buildProxy(raw) {
  let full = raw.trim();
  if (!/^https?:\/\//i.test(full) && !/^socks/i.test(full)) full = `http://${full}`;
  let parsed;
  try { parsed = new URL(full); } catch { throw new Error(`Cannot parse proxy: ${raw}`); }
  return { url: full, label: `${parsed.hostname}:${parsed.port}`, raw };
}
function pickRandomProxy(proxies) { return proxies[Math.floor(Math.random() * proxies.length)]; }
async function verifyProxy(raw, tag) {
  const p = buildProxy(raw);
  const { execSync } = await import('child_process');
  for (const checkUrl of IP_CHECK_URLS) {
    try {
      const result = execSync(`curl -s --max-time 12 --proxy "${p.url}" "${checkUrl}"`, { timeout: PROXY_CHECK_TIMEOUT + 3000 }).toString().trim();
      let ip = null;
      try { const j = JSON.parse(result); ip = j.ip || j.address || j.query; } catch {}
      if (!ip && /^\d{1,3}(\.\d{1,3}){3}$/.test(result)) ip = result;
      if (ip) {
        console.log(`  ${tag} [PROXY] ✓ ${p.label} → verified IP: ${ip}`);
        return { ...p, ip };
      }
    } catch {}
  }
  throw new Error(`Proxy unreachable: ${p.label}`);
}
async function pickWorkingProxy(proxies, tag) {
  for (let attempt = 1; attempt <= PROXY_MAX_RETRIES; attempt++) {
    const raw = pickRandomProxy(proxies);
    const label = buildProxy(raw).label;
    console.log(`  ${tag} [PROXY] attempt [${attempt}/${PROXY_MAX_RETRIES}]: ${label}`);
    try {
      const proxy = await verifyProxy(raw, tag);
      console.log(`  ${tag} [PROXY] locked in: ${proxy.label} (IP: ${proxy.ip})`);
      return proxy;
    } catch (err) {
      console.log(`  ${tag} [PROXY] ✗ ${err.message} — retrying...`);
    }
  }
  throw new Error(`No working proxy found after ${PROXY_MAX_RETRIES} attempts for ${tag}`);
}

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function now(){ return new Date().toISOString(); }
function waitMs(activity){
  if (FAST) return 5000;
  if (activity === 'recon_i_short') return 31 * 60 * 1000;
  return 21 * 60 * 1000;
}
async function readJsonl(file){
  try { return (await fs.readFile(file, 'utf8')).split(/\r?\n/).filter(Boolean).map(x => JSON.parse(x)); }
  catch(e){ if (e.code === 'ENOENT') return []; throw e; }
}
async function readPipeCookies(file=COOKIE_FILE){
  try {
    return (await fs.readFile(file, 'utf8')).split(/\r?\n/).filter(Boolean).map(line => {
      const parts = line.split('|');
      const email = parts[0];
      const cookie = parts[1] || '';
      let agentId = null, expiresAt = 0, savedAt = 0;
      if (parts.length >= 5) { agentId = parts[2] || null; expiresAt = Number(parts[3] || 0); savedAt = Number(parts[4] || 0); }
      else if (parts.length >= 4) {
        const p2 = Number(parts[2] || 0);
        if (p2 > 10_000_000_000) { expiresAt = p2; savedAt = Number(parts[3] || 0); }
        else { agentId = parts[2] || null; savedAt = Number(parts[3] || 0); }
      }
      return { email, id: email, cookie, agentId, expiresAt, savedAt };
    });
  } catch(e){ if (e.code === 'ENOENT') return []; throw e; }
}
function cookieUsable(account){
  const exp = Number(account.expiresAt || 0);
  if (!exp) return true;
  const hours = Math.floor((exp - Date.now()) / 3600000);
  if (hours < 24) console.log(`[COOKIE ALERT] ${account.id} cookie expires in ${hours}h (<24h).`);
  if (hours <= 12) { console.log(`[${account.id}] skip cookie; expires in ${hours}h (<=12h)`); return false; }
  return true;
}
async function upsertCookieAgent(email, cookie, agentId){
  if (!email || !cookie) return;
  let rows = await readPipeCookies();
  const key = String(email).trim().toLowerCase();
  rows = rows.filter(r => String(r.email || '').trim().toLowerCase() !== key);
  const old = (await readPipeCookies()).find(r => String(r.email || '').trim().toLowerCase() === key) || {};
  rows.push({ email: String(email).trim(), cookie, agentId: agentId || '', expiresAt: old.expiresAt || '' });
  const out = rows.map(r => [r.email, r.cookie, r.agentId || '', r.expiresAt || '', Date.now()].join('|')).join('\n') + '\n';
  await fs.writeFile(COOKIE_FILE, out);
}
async function loadCache(){
  try { return JSON.parse(await fs.readFile(CACHE_FILE, 'utf8')); }
  catch(e){ if (e.code === 'ENOENT') return {}; throw e; }
}
async function saveCache(cache){ await fs.writeFile(CACHE_FILE, JSON.stringify(cache, null, 2)); }
async function log(row){ await fs.appendFile(LOG_FILE, JSON.stringify({ ts: now(), ...row }) + '\n'); }
function cookieObjects(cookieHeader){
  return String(cookieHeader || '').split(';').map(s => s.trim()).filter(Boolean).map(pair => {
    const i = pair.indexOf('=');
    return { name: pair.slice(0, i), value: pair.slice(i + 1), domain: 'doppel.fun', path: '/', secure: true, sameSite: 'Lax' };
  }).filter(c => c.name && c.value);
}
async function openAccountBrowser(account, proxies){
  const args = ['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'];
  const profileKey = String(account.id || account.email || 'account').replace(/[^a-zA-Z0-9_.-]/g, '_');
  const profileDir = path.join(ROOT, 'quest_profiles', profileKey);
  const proxy = await pickWorkingProxy(proxies, account.id || account.email || profileKey);
  const context = await launchPersistentContext({ userDataDir: profileDir, headless: false, proxy: proxy.url, args, locale: 'en-US', timezone: 'America/New_York', userAgent: UA });
  await context.addCookies(cookieObjects(account.cookie));
  const page = context.pages()[0] || await context.newPage();
  await page.goto(account.agentId ? `https://doppel.fun/agent/${account.agentId}` : 'https://doppel.fun/', { waitUntil: 'domcontentloaded', timeout: 90000 });
  console.log(`[${account.id}] waiting for Vercel/browser verification...`);
  let ready = false;
  for (let i = 0; i < 5; i++){
    await page.waitForTimeout(2000);
    const check = await page.evaluate(async () => {
      const body = document.body?.innerText || '';
      try {
        const res = await fetch('/api/accounts/me', { credentials: 'include' });
        return { status: res.status, text: await res.text(), body: body.slice(0,200) };
      } catch(e){
        return { status: 0, text: e.message, body: body.slice(0,200) };
      }
    }).catch(e => ({ status: 0, text: e.message, body: '' }));
    if (check.status === 200) { ready = true; break; }
    if (i % 5 === 0) console.log(`[${account.id}] verify wait status=${check.status} body=${String(check.body).slice(0,80)}`);
    if (check.status === 401) break;
  }
  if (!ready) console.log(`[${account.id}] verification not ready; trying quest anyway`);
  return { context, page };
}
async function req(account, endpoint, opts={}){
  if (!account.page) throw new Error('account browser page missing');
  const out = await account.page.evaluate(async ({ endpoint, opts }) => {
    const url = endpoint.startsWith('/api/') ? endpoint : `/api${endpoint}`;
    const res = await fetch(url, {
      credentials: 'include',
      ...opts,
      headers: { 'content-type': 'application/json', ...(opts.headers || {}) },
    });
    const text = await res.text();
    let data = text;
    try { data = JSON.parse(text); } catch {}
    return { ok: res.ok, status: res.status, text, data };
  }, { endpoint, opts });
  if (!out.ok) throw new Error(`${opts.method || 'GET'} ${endpoint} ${out.status}: ${String(out.text).slice(0,300)}`);
  return out.data;
}

async function avatarTo100(account){
  for (let i = 0; i < 300; i++){
    const out = await req(account, '/care/avatar-tap', { method: 'POST', body: JSON.stringify({ agentId: account.agentId }) });
    const mood = out?.vitals?.mood;
    if (i % 10 === 0 || mood >= 100) console.log(`[${account.id}] avatar mood=${mood}`);
    if (mood >= 100) return out;
    await sleep(150);
  }
  return { error: 'avatar mood did not reach 100' };
}

async function resolveIfDue(account, cache){
  const c = cache[account.id];
  if (!c?.resolveAt) return false;
  const left = c.resolveAt - Date.now();
  if (left > 0) {
    console.log(`[${account.id}] pending ${c.activity}, resolve in ${Math.ceil(left/1000)}s`);
    return true;
  }
  console.log(`[${account.id}] resolving ${c.activity}`);
  const resolved = await req(account, '/care/resolve', { method: 'POST', body: JSON.stringify({ agentId: account.agentId, returnFromCity: true }) });
  const avatar = await avatarTo100(account);
  delete cache[account.id];
  await saveCache(cache);
  await log({ id: account.id, agentId: account.agentId, event: 'resolved', activity: c.activity, cycleId: c.cycleId, resolved, avatar });
  return false;
}

async function assign(account, cache){
  let home;
  try {
    home = await req(account, `/care/home?agentId=${encodeURIComponent(account.agentId)}`);
  } catch (e) {
    console.log(`[${account.id}] home failed for agentId=${account.agentId}; refreshing from /api/care/agents`);
    await discoverAgentId(account, true);
    home = await req(account, `/care/home?agentId=${encodeURIComponent(account.agentId)}`);
  }
  const compute = Number(home.computeEarnedTodayCu || 0);
  const activity = compute > 131 ? 'recon_i_short' : 'training';
  console.log(`[${account.id}] compute=${compute} assign=${activity}`);
  let assigned;
  try {
    assigned = await req(account, '/care/assign', { method: 'POST', body: JSON.stringify({ agentId: account.agentId, activity }) });
  } catch (e) {
    if (String(e.message || '').includes('409') && String(e.message || '').includes('active task')) {
      console.log(`[${account.id}] active task detected; resolving then avatar tap`);
      const resolved = await req(account, '/care/resolve', { method: 'POST', body: JSON.stringify({ agentId: account.agentId, returnFromCity: true }) });
      const avatar = await avatarTo100(account);
      delete cache[account.id];
      await saveCache(cache);
      await log({ id: account.id, agentId: account.agentId, event: 'resolved-active-task', activity, resolved, avatar });
      console.log(`[${account.id}] active task resolved; avatar tap done`);
      return;
    }
    throw e;
  }
  const act = assigned?.cycle?.activity || activity;
  const resolveAt = Date.now() + waitMs(act);
  cache[account.id] = {
    id: account.id,
    agentId: account.agentId,
    activity: act,
    cycleId: assigned?.cycle?.id || null,
    assignedAt: Date.now(),
    resolveAt,
    status: 'pending',
  };
  await saveCache(cache);
  await log({ id: account.id, agentId: account.agentId, event: 'assigned', activity: act, resolveAt, assigned });
  console.log(`[${account.id}] assigned ${act}, resolveAt=${new Date(resolveAt).toISOString()}`);
}

async function discoverAgentId(account, force=false){
  const agentsResp = await req(account, '/care/agents');
  const list = Array.isArray(agentsResp) ? agentsResp : (agentsResp.agents || agentsResp.data || agentsResp.items || []);
  const first = Array.isArray(list) ? list[0] : list;
  const freshAgentId = first?.id || first?.agentId || first?._id || first?.agent?.id || agentsResp?.agent?.id || agentsResp?.id;
  if (!freshAgentId) throw new Error(`No agent found from /api/care/agents: ${JSON.stringify(agentsResp).slice(0, 300)}`);
  if (freshAgentId !== account.agentId) console.log(`[${account.id}] agentId update ${account.agentId || 'none'} -> ${freshAgentId}`);
  account.agentId = freshAgentId;
  await upsertCookieAgent(account.email || account.id, account.cookie, freshAgentId);
  return freshAgentId;
}

async function processAccount(account, cache, proxies){
  let context = null;
  try {
    const opened = await openAccountBrowser(account, proxies);
    context = opened.context;
    account.page = opened.page;
    const debug = await account.page.evaluate(async () => {
      const get = async u => { const r = await fetch(u, { credentials: 'include' }); const text = await r.text(); return { u, status: r.status, text: text.slice(0,500) }; };
      return { me: await get('/api/accounts/me'), agents: await get('/api/care/agents') };
    });
    console.log(`[${account.id}] me=${debug.me.status} agents=${debug.agents.status} ${debug.agents.text.slice(0,180)}`);
    await discoverAgentId(account);
    const pending = await resolveIfDue(account, cache);
    if (!pending && cache[account.id]?.status !== 'pending') await assign(account, cache);
  } catch(e){
    console.log(`[${account.id}] failed ${e.message}`);
    await log({ id: account.id, agentId: account.agentId, event: 'failed', error: e.message });
  } finally {
    if (context) await context.close().catch(() => {});
  }
}

async function runPool(items, worker){
  let next = 0;
  const workers = Array.from({ length: Math.min(CONCURRENCY, items.length) }, async () => {
    while (next < items.length) {
      const item = items[next++];
      await worker(item);
    }
  });
  await Promise.all(workers);
}

async function main(){
  const proxies = await loadProxies();
  let accounts = await readPipeCookies();
  accounts = accounts.filter(a => a.cookie && cookieUsable(a)).map(a => ({ ...a, id: a.id || a.email }));
  if (LIMIT) accounts = accounts.slice(0, LIMIT);
  if (!accounts.length) throw new Error(`No usable coinbase cookies in ${COOKIE_FILE}`);
  console.log(`Loaded cookies from dopcbcookies.txt; agentId will be discovered from API.`);
  const cache = await loadCache();
  console.log(`Loaded ${accounts.length} coinbase accounts. concurrency=${CONCURRENCY} once=${ONCE}`);
  await runPool(accounts, account => processAccount(account, cache, proxies));
  await saveCache(cache);
  if (!ONCE) console.log('Run this script again later, or schedule it, to resolve cached assignments.');
}
main().catch(e => { console.error('[FATAL]', e.stack || e.message); process.exit(1); });

