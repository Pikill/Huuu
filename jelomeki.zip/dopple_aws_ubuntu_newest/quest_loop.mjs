#!/usr/bin/env node
import fs from 'fs/promises';
import path from 'path';

const ROOT = process.cwd();
const API = 'https://doppel.fun/api';
const COOKIE_FILE = path.join(ROOT, 'dopcbcookies.txt');
const CACHE_FILE = path.join(ROOT, 'quest_cache.json');
const LOG_FILE = path.join(ROOT, 'quest_results.jsonl');
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36';
const LIMIT = Number(process.env.LIMIT || process.argv.find(a => a.startsWith('--limit='))?.split('=')[1] || 0);
const CONCURRENCY = Math.min(5, Math.max(1, Number(process.env.CONCURRENCY || process.argv.find(a => a.startsWith('--concurrency='))?.split('=')[1] || 1)));
const FAST = process.argv.includes('--fast');

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function now(){ return new Date().toISOString(); }
function waitMs(activity){
  if (FAST) return 5000;
  if (activity === 'recon_i_short') return 31 * 60 * 1000;
  return 21 * 60 * 1000;
}
async function readPipeCookies(file=COOKIE_FILE){
  try {
    return (await fs.readFile(file, 'utf8')).split(/\r?\n/).filter(Boolean).map(line => {
      const parts = line.split('|');
      const email = parts[0];
      const cookie = parts[1] || '';
      let agentId = null, expiresAt = 0, savedAt = 0;
      if (parts.length >= 5) { agentId = parts[2] || null; expiresAt = Number(parts[3] || 0); savedAt = Number(parts[4] || 0); }
      else if (parts.length >= 4) {
        const p2 = Number(parts[2] || 0);
        if (p2 > 10_000_000_000) { expiresAt = p2; savedAt = Number(parts[3] || 0); }
        else { agentId = parts[2] || null; savedAt = Number(parts[3] || 0); }
      }
      return { email, id: email, cookie, agentId, expiresAt, savedAt };
    });
  } catch(e){ if (e.code === 'ENOENT') return []; throw e; }
}
function cookieUsable(account){
  const exp = Number(account.expiresAt || 0);
  if (!exp) return true;
  const hours = Math.floor((exp - Date.now()) / 3600000);
  if (hours < 24) console.log(`[COOKIE ALERT] ${account.id} cookie expires in ${hours}h (<24h).`);
  if (hours <= 12) { console.log(`[${account.id}] skip cookie; expires in ${hours}h (<=12h)`); return false; }
  return true;
}
async function upsertCookieAgent(email, cookie, agentId){
  if (!email || !cookie) return;
  let rows = await readPipeCookies();
  const key = String(email).trim().toLowerCase();
  rows = rows.filter(r => String(r.email || '').trim().toLowerCase() !== key);
  const old = (await readPipeCookies()).find(r => String(r.email || '').trim().toLowerCase() === key) || {};
  rows.push({ email: String(email).trim(), cookie, agentId: agentId || '', expiresAt: old.expiresAt || '' });
  const out = rows.map(r => [r.email, r.cookie, r.agentId || '', r.expiresAt || '', Date.now()].join('|')).join('\n') + '\n';
  await fs.writeFile(COOKIE_FILE, out);
}
async function loadCache(){
  try { return JSON.parse(await fs.readFile(CACHE_FILE, 'utf8')); }
  catch(e){ if (e.code === 'ENOENT') return {}; throw e; }
}
async function saveCache(cache){ await fs.writeFile(CACHE_FILE, JSON.stringify(cache, null, 2)); }
async function log(row){ await fs.appendFile(LOG_FILE, JSON.stringify({ ts: now(), mode: 'url', ...row }) + '\n'); }
function cookieHeader(cookie){ return String(cookie || '').trim(); }
async function req(account, endpoint, opts={}){
  const url = endpoint.startsWith('http') ? endpoint : `${API}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
  const res = await fetch(url, {
    ...opts,
    headers: {
      'accept': 'application/json, text/plain, */*',
      'content-type': 'application/json',
      'cookie': cookieHeader(account.cookie),
      'origin': 'https://doppel.fun',
      'referer': account.agentId ? `https://doppel.fun/agent/${account.agentId}` : 'https://doppel.fun/',
      'user-agent': UA,
      ...(opts.headers || {}),
    },
  });
  const text = await res.text();
  let data = text;
  try { data = JSON.parse(text); } catch {}
  if (!res.ok) throw new Error(`${opts.method || 'GET'} ${endpoint} ${res.status}: ${String(text).slice(0,300)}`);
  return data;
}
async function verify(account){
  const me = await req(account, '/accounts/me').catch(e => ({ error: e.message }));
  const agents = await req(account, '/care/agents').catch(e => ({ error: e.message }));
  console.log(`[${account.id}] me=${me?.error || 'ok'} agents=${agents?.error || JSON.stringify(agents).slice(0,180)}`);
  if (me?.error) throw new Error(`auth failed: ${me.error}`);
  return agents;
}
async function discoverAgentId(account){
  const agentsResp = await req(account, '/care/agents');
  const list = Array.isArray(agentsResp) ? agentsResp : (agentsResp.agents || agentsResp.data || agentsResp.items || []);
  const first = Array.isArray(list) ? list[0] : list;
  const freshAgentId = first?.id || first?.agentId || first?._id || first?.agent?.id || agentsResp?.agent?.id || agentsResp?.id;
  if (!freshAgentId) throw new Error(`No agent found from /api/care/agents: ${JSON.stringify(agentsResp).slice(0,300)}`);
  if (freshAgentId !== account.agentId) console.log(`[${account.id}] agentId update ${account.agentId || 'none'} -> ${freshAgentId}`);
  account.agentId = freshAgentId;
  await upsertCookieAgent(account.email || account.id, account.cookie, freshAgentId);
  return freshAgentId;
}
async function avatarTo100(account){
  for (let i = 0; i < 300; i++){
    const out = await req(account, '/care/avatar-tap', { method: 'POST', body: JSON.stringify({ agentId: account.agentId }) });
    const mood = out?.vitals?.mood;
    if (i % 10 === 0 || mood >= 100) console.log(`[${account.id}] avatar mood=${mood}`);
    if (mood >= 100) return out;
    await sleep(150);
  }
  return { error: 'avatar mood did not reach 100' };
}
async function resolveIfDue(account, cache){
  const c = cache[account.id];
  if (!c?.resolveAt) return false;
  const left = c.resolveAt - Date.now();
  if (left > 0) {
    console.log(`[${account.id}] pending ${c.activity}, resolve in ${Math.ceil(left/1000)}s`);
    return true;
  }
  console.log(`[${account.id}] resolving ${c.activity}`);
  const resolved = await req(account, '/care/resolve', { method: 'POST', body: JSON.stringify({ agentId: account.agentId, returnFromCity: true }) });
  const avatar = await avatarTo100(account);
  delete cache[account.id];
  await saveCache(cache);
  await log({ id: account.id, agentId: account.agentId, event: 'resolved', activity: c.activity, cycleId: c.cycleId, resolved, avatar });
  return false;
}
async function assign(account, cache){
  let home;
  try {
    home = await req(account, `/care/home?agentId=${encodeURIComponent(account.agentId)}`);
  } catch (e) {
    console.log(`[${account.id}] home failed for agentId=${account.agentId}; refreshing from /api/care/agents`);
    await discoverAgentId(account);
    home = await req(account, `/care/home?agentId=${encodeURIComponent(account.agentId)}`);
  }
  const compute = Number(home.computeEarnedTodayCu || 0);
  const activity = compute > 131 ? 'recon_i_short' : 'training';
  console.log(`[${account.id}] compute=${compute} assign=${activity}`);
  const assigned = await req(account, '/care/assign', { method: 'POST', body: JSON.stringify({ agentId: account.agentId, activity }) });
  const act = assigned?.cycle?.activity || activity;
  const resolveAt = Date.now() + waitMs(act);
  cache[account.id] = { id: account.id, agentId: account.agentId, activity: act, cycleId: assigned?.cycle?.id || null, assignedAt: Date.now(), resolveAt, status: 'pending' };
  await saveCache(cache);
  await log({ id: account.id, agentId: account.agentId, event: 'assigned', activity: act, resolveAt, assigned });
  console.log(`[${account.id}] assigned ${act}, resolveAt=${new Date(resolveAt).toISOString()}`);
}
async function processAccount(account, cache){
  try {
    await verify(account);
    await discoverAgentId(account);
    const pending = await resolveIfDue(account, cache);
    if (!pending && cache[account.id]?.status !== 'pending') await assign(account, cache);
  } catch(e){
    console.log(`[${account.id}] failed ${e.message}`);
    await log({ id: account.id, agentId: account.agentId, event: 'failed', error: e.message });
  }
}
async function runPool(items, worker){
  let next = 0;
  const workers = Array.from({ length: Math.min(CONCURRENCY, items.length) }, async () => {
    while (next < items.length) await worker(items[next++]);
  });
  await Promise.all(workers);
}
async function main(){
  let accounts = await readPipeCookies();
  accounts = accounts.filter(a => a.cookie && cookieUsable(a)).map(a => ({ ...a, id: a.id || a.email }));
  if (LIMIT) accounts = accounts.slice(0, LIMIT);
  if (!accounts.length) throw new Error(`No usable coinbase cookies in ${COOKIE_FILE}`);
  console.log(`URL quest mode. Loaded cookies from dopcbcookies.txt.`);
  const cache = await loadCache();
  console.log(`Loaded ${accounts.length} coinbase accounts. concurrency=${CONCURRENCY}`);
  await runPool(accounts, account => processAccount(account, cache));
  await saveCache(cache);
}
main().catch(e => { console.error('[FATAL]', e.stack || e.message); process.exit(1); });
