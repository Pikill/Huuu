#!/usr/bin/env node
import fs from 'fs/promises';
import readline from 'readline/promises';
import { stdin as input, stdout as output } from 'process';
import { spawn } from 'child_process';
import path from 'path';

const ROOT = process.cwd();
const rl = readline.createInterface({ input, output });

function modeName(choice){
  if (choice === '1') return 'sign up/create account only';
  if (choice === '2') return 'login/create agent';
  if (choice === '3') return 'renew cookies only';
  if (choice === '4') return 'quest loop';
  if (choice === '5') return 'exit';
  throw new Error('Invalid option');
}
function modeArgs(choice, email){
  const args = ['coinbase_cloak_auto.mjs', `--email=${email}`];
  if (choice === '1') args.push('--create-account-only');
  if (choice === '3') args.push('--renew-cookies');
  return args;
}
async function loadEmails(raw){
  raw = String(raw || '').trim();
  if (!raw) throw new Error('Email/list is required');
  if (raw.startsWith('@')) {
    const file = path.isAbsolute(raw.slice(1)) ? raw.slice(1) : path.join(ROOT, raw.slice(1));
    return (await fs.readFile(file, 'utf8')).split(/\r?\n|,/).map(x => x.trim()).filter(Boolean);
  }
  return raw.split(/\s*,\s*|\s+/).map(x => x.trim()).filter(Boolean);
}
function profileFor(slot){
  return path.join(ROOT, `profileS${slot}`);
}
function run(cmd, args, env={}){
  return new Promise((resolve) => {
    const p = spawn(cmd, args, { cwd: ROOT, env: { ...process.env, ...env }, stdio: 'inherit', shell: false });
    p.on('exit', code => resolve(code));
  });
}
async function runQuest(){
  const concurrencyRaw = (await rl.question('How many accounts running at same time? [1]: ')).trim();
  const concurrency = Math.min(5, Math.max(1, Number(concurrencyRaw || 1)));
  const limitRaw = (await rl.question('Limit accounts? 0 = all [0]: ')).trim();
  const limit = Math.max(0, Number(limitRaw || 0));
  const loopRaw = (await rl.question('Loop every 5 minutes? y/N: ')).trim().toLowerCase();
  const args = ['quest_loop_browser.mjs', '--once', `--concurrency=${concurrency}`];
  if (limit) args.push(`--limit=${limit}`);
  if (loopRaw === 'y' || loopRaw === 'yes') {
    console.log('Quest loop started. Stop with Ctrl+C.');
    while (true) {
      await run('node', args);
      await new Promise(r => setTimeout(r, 300000));
    }
  } else {
    await run('node', args);
  }
}

async function main(){
  console.log('Coinbase/Doppel interactive');
  console.log('1) Sign up / create account only');
  console.log('2) Login / create agent');
  console.log('3) Renew cookies only');
  console.log('4) Quest loop');
  console.log('5) Exit');
  const choice = (await rl.question('Choose option [1-5]: ')).trim();
  if (choice === '5') {
    console.log('Exit.');
    return;
  }
  if (choice === '4') {
    await runQuest();
    return;
  }
  const emails = await loadEmails(await rl.question('Email(s), comma/space separated, or @file: '));
  console.log(`Mode: ${modeName(choice)}`);
  console.log(`Accounts: ${emails.length}`);
  console.log('Profiles rotate through 5 total slots for all modes: profileS1..profileS5. OTP is entered one account at a time.');

  for (let i = 0; i < emails.length; i++) {
    const email = emails[i];
    const slot = (i % 5) + 1;
    const profileDir = profileFor(slot);
    console.log(`\n=== ${i + 1}/${emails.length} slot=${slot} email=${email} ===`);
    console.log(`Profile: ${profileDir}`);
    const code = await run('node', [...modeArgs(choice, email), `--profile-slot=${slot}`], { PROFILE_SLOT: String(slot) });
    if (code !== 0) {
      console.log(`[WARN] ${email} exited with code ${code}. Continuing to next account.`);
    }
  }
  console.log('\n[DONE] All accounts processed.');
}

main().catch(e => { console.error('[FATAL]', e.stack || e.message); process.exit(1); }).finally(() => rl.close());
