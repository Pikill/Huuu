# Doppel Automation — AWS Ubuntu

## 1) Copy folder to AWS

```bash
scp -r dopple_aws_ubuntu ubuntu@YOUR_AWS_IP:~/
```

## 2) Install dependencies

```bash
cd ~/dopple_aws_ubuntu
bash scripts/install_ubuntu.sh
```

## 3) Run hidden mode

```bash
npm start
```

This starts Xvfb and opens the interactive menu in terminal.

## 4) Run local/visible mode

Use this only if your AWS instance has VNC/desktop forwarding.

```bash
npm run local
```

## 5) Menu

```text
1) Sign up / create account only
2) Login / create agent
3) Renew cookies only
4) Quest loop
5) Exit
```

## 6) Quest loop

Default quest is browser mode:

```bash
npm run quest
```

URL fallback:

```bash
npm run quest:url
```

## 7) Profiles

The script auto-creates and uses:

```text
profileS1
profileS2
profileS3
profileS4
profileS5
```

## 8) Data files created at runtime

```text
dopcbcookies.txt
dopcbaccounts.jsonl
dopcb_created_accounts.jsonl
quest_cache.json
quest_results.jsonl
all_addresses.txt
```

Do not commit/share cookie files.

## 9) Export addresses

```bash
npm run export:addresses
```

Output:

```text
all_addresses.txt
```

Format:

```text
email|address
```
