#!/usr/bin/env node
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import readline from 'readline/promises';
import promptSync from 'prompt-sync';
import { stdin as input, stdout as output } from 'process';
import { launchPersistentContext } from 'cloakbrowser';
import * as cheerio from 'cheerio';
import fsSyncModule from 'fs';
const fsSync = fsSyncModule;

const ROOT = process.cwd();
const ORIGIN = 'https://doppel.fun';
const OUT = path.join(ROOT, 'coinbase_cloak_results.jsonl');
const SESSION_FILE = path.join(ROOT, 'dopcbsess.txt');
const COINBASE_COOKIE_FILE = path.join(ROOT, 'dopcbcookies.txt');
const COINBASE_ACCOUNT_FILE = path.join(ROOT, 'dopcbaccounts.jsonl');
const COINBASE_CREATED_ACCOUNT_FILE = path.join(ROOT, 'dopcb_created_accounts.jsonl');
const EXPLORE_LOG = path.join(ROOT, 'coinbase_explore_events.jsonl');
const slotArg = process.argv.find(a => a.startsWith('--profile-slot='))?.split('=')[1] || process.env.PROFILE_SLOT || '1';
const PROFILE_SLOT = Math.min(5, Math.max(1, Number(slotArg) || 1));
const PROFILE_DIR = path.join(ROOT, `profileS${PROFILE_SLOT}`);
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36';
const DO_CHECKIN = process.argv.includes('--checkin') || process.env.CHECKIN === '1';
const CREATE_ACCOUNT_ONLY = process.argv.includes('--create-account-only') || process.env.CREATE_ACCOUNT_ONLY === '1';
const RENEW_COOKIES_ONLY = process.argv.includes('--renew-cookies') || process.env.RENEW_COOKIES_ONLY === '1';
const TRAITS = ['Friendly','Technical','Creative','Calm','Bold','Supportive','Curious','Pragmatic','Playful','Thoughtful','Sarcastic','Blunt','Mysterious','Mischievous'];
const TOPICS = ['history','architecture','technology','science','music','gaming','art','literature'];
const NAMES = ['Nova','Echo','Axiom','Pulse','Flux','Orion','Cipher','Kairo','Mira','Zed','Luna','Core','Drift','Nexus','Vera','Sol'];

const PROXIES_FILE = path.join(ROOT, 'proxies.txt');
const PROXY_CHECK_TIMEOUT = 15_000;
const PROXY_MAX_RETRIES   = 5;
const IP_CHECK_URLS = [
  'https://api.ipify.org?format=json',
  'https://ifconfig.me/ip',
  'https://api.my-ip.io/ip.json',
];

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function pick(arr,n){ return [...arr].sort(() => Math.random() - 0.5).slice(0,n); }
function randomName(){ return `${pick(NAMES,1)[0]}${crypto.randomBytes(2).toString('hex')}`; }
function spdlPid(){ return Array.from(crypto.randomBytes(32), b => '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'[b % 62]).join(''); }
function deviceId(){ return crypto.randomUUID(); }
function txOf(x){ return x?.txHash || x?.hash || x?.transactionHash || x?.data?.txHash || x?.result?.txHash || x?.result?.hash; }
function agentIdOf(x){ return x?.id || x?.agentId || x?._id || x?.agent?.id || x?.agent?.agentId || x?.data?.id || x?.data?.agentId; }
// ─── PROXY SYSTEM ────────────────────────────────────────────────────────────

function loadProxies() {
  if (!fsSync.existsSync(PROXIES_FILE)) {
    throw new Error(`FATAL: proxies.txt not found at ${PROXIES_FILE}\nAdd proxies in format: username:password@host:port  (one per line)`);
  }
  const lines = fsSync.readFileSync(PROXIES_FILE, 'utf-8')
    .split('\n').map(l => l.trim()).filter(Boolean).filter(l => !l.startsWith('#'));
  if (!lines.length) throw new Error('FATAL: proxies.txt is empty.');
  console.log(`[PROXY] Loaded ${lines.length} proxy line(s) from proxies.txt`);
  return lines;
}

function buildProxy(raw) {
  // Normalise: add scheme if missing
  let full = raw.trim();
  if (!/^https?:\/\//i.test(full) && !/^socks/i.test(full)) full = `http://${full}`;
  let parsed;
  try { parsed = new URL(full); } catch { throw new Error(`Cannot parse proxy: ${raw}`); }

  // Server URL must NOT contain credentials — Playwright rejects ERR_INVALID_AUTH_CREDENTIALS
  // when username:password are embedded in the server string.
  const server = `${parsed.protocol}//${parsed.hostname}:${parsed.port}`;
  const username = decodeURIComponent(parsed.username || '');
  const password = decodeURIComponent(parsed.password || '');
  const label    = `${parsed.hostname}:${parsed.port}`;

  return { server, username, password, label, raw };
}

function pickRandomProxy(proxies) {
  return proxies[Math.floor(Math.random() * proxies.length)];
}

async function verifyProxy(raw, tag) {
  const p       = buildProxy(raw);
  const proxyUrl = p.server + (p.username ? ` (auth: ${p.username})` : '');
  const label    = p.label;
  // curl needs the full URL with credentials for verification
  const curlProxy = raw.trim().startsWith('http') || raw.trim().startsWith('socks')
    ? raw.trim() : `http://${raw.trim()}`;
  for (const checkUrl of IP_CHECK_URLS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), PROXY_CHECK_TIMEOUT);
    try {
      // Use Node's fetch with undici-style proxy via env passthrough — but
      // for verification we just do a direct fetch THROUGH the proxy by
      // launching a tiny one-shot check via the system's curl which respects
      // http_proxy, or we use a native approach.  Since undici ProxyAgent
      // isn't in scope here (browser handles the proxy), we verify by
      // checking that the browser proxy flag is accepted. For pure Node-side
      // verification we fall back to a subprocess curl call.
      const { execSync } = await import('child_process');
      const result = execSync(
        `curl -s --max-time 12 --proxy "${curlProxy}" "${checkUrl}"`,
        { timeout: PROXY_CHECK_TIMEOUT + 3000 }
      ).toString().trim();
      clearTimeout(timer);
      let ip = null;
      try { const j = JSON.parse(result); ip = j.ip || j.address || j.query; } catch {}
      if (!ip && /^\d{1,3}(\.\d{1,3}){3}$/.test(result)) ip = result;
      if (ip) {
        console.log(`  ${tag} [PROXY] ✓ ${label} → verified IP: ${ip}`);
        return { ...buildProxy(raw), ip };
      }
    } catch (err) {
      clearTimeout(timer);
    }
  }
  throw new Error(`Proxy unreachable: ${label}`);
}

async function pickWorkingProxy(proxies, tag) {
  for (let attempt = 1; attempt <= PROXY_MAX_RETRIES; attempt++) {
    const raw = pickRandomProxy(proxies);
    const label = buildProxy(raw).label;
    console.log(`  ${tag} [PROXY] attempt [${attempt}/${PROXY_MAX_RETRIES}]: ${label}`);
    try {
      const proxy = await verifyProxy(raw, tag);
      console.log(`  ${tag} [PROXY] locked in: ${proxy.label} (IP: ${proxy.ip})`);
      return proxy;
    } catch (err) {
      console.log(`  ${tag} [PROXY] ✗ ${err.message} — retrying...`);
    }
  }
  throw new Error(`No working proxy found after ${PROXY_MAX_RETRIES} attempts for ${tag}`);
}

// ─────────────────────────────────────────────────────────────────────────────

async function append(row){ await fs.appendFile(OUT, JSON.stringify({ ts: new Date().toISOString(), ...row }) + '\n'); }
async function logExplore(row){ await fs.appendFile(EXPLORE_LOG, JSON.stringify({ ts: new Date().toISOString(), ...row }) + '\n').catch(() => {}); }
async function upsertPipeByEmail(file, email, fields){
  const safeEmail = String(email).trim().toLowerCase();
  let lines = [];
  try { lines = (await fs.readFile(file, 'utf8')).split(/\r?\n/).filter(Boolean); } catch(e){ if (e.code !== 'ENOENT') throw e; }
  const out = lines.filter(line => String(line.split('|')[0] || '').trim().toLowerCase() !== safeEmail);
  out.push([String(email).trim(), ...fields, Date.now()].join('|'));
  await fs.writeFile(file, out.join('\n') + '\n');
}
function cookieExpiryMs(cookies, name='doppel_session'){
  const c = cookies.find(x => x.name === name);
  if (!c?.expires || c.expires <= 0) return 0;
  return Math.floor(c.expires * 1000);
}
function expiryFields(cookies){
  const exp = cookieExpiryMs(cookies);
  if (!exp) return { exp: '', hoursLeft: '' };
  const hoursLeft = Math.floor((exp - Date.now()) / 3600000);
  if (hoursLeft < 24) console.log(`[COOKIE ALERT] doppel_session expires in ${hoursLeft}h (<24h). Renew soon.`);
  else if (hoursLeft < 12) console.log(`[COOKIE ALERT] doppel_session expires in ${hoursLeft}h (<12h). Do not reuse; renew now.`);
  return { exp: String(exp), hoursLeft: String(hoursLeft) };
}
function canReuseCookie(expMs){
  if (!expMs) return true;
  return (expMs - Date.now()) > 12 * 3600000;
}
async function saveSession(email, session){
  if (!session) return;
  await upsertPipeByEmail(SESSION_FILE, email, [session]);
}
async function saveCookieHeader(email, cookie, expMs=''){
  if (!cookie) return;
  await upsertPipeByEmail(COINBASE_COOKIE_FILE, email, [cookie, expMs || '']);
}
async function upsertJsonlById(file, id, row){
  let lines = [];
  try { lines = (await fs.readFile(file, 'utf8')).split(/\r?\n/).filter(Boolean); } catch(e){ if (e.code !== 'ENOENT') throw e; }
  const out = [];
  for (const line of lines){
    try {
      const obj = JSON.parse(line);
      if (String(obj.id || obj.address || obj.email || '').toLowerCase() === id.toLowerCase()) continue;
    } catch {}
    out.push(line);
  }
  out.push(JSON.stringify({ ts: new Date().toISOString(), id, ...row }));
  await fs.writeFile(file, out.join('\n') + '\n');
}
function sessionFromSetCookie(setCookie=''){
  const m = String(setCookie).match(/(?:^|,\s*)doppel_session=([^;]+)/);
  return m ? m[1] : null;
}

async function latestBaseTx(address, retries=1){
  const url = `https://basescan.org/address/${address}#internaltx`;
  for (let i=0;i<retries;i++){
    const res = await fetch(url, { headers: { 'user-agent': UA } });
    if (res.ok){
      const $ = cheerio.load(await res.text());
      const hashes = [];
      $('a[href*="/tx/"], table tbody tr td').each((_, el) => {
        for (const v of [$(el).text(), $(el).attr('href') || '']){
          const m = String(v).match(/0x[a-fA-F0-9]{64}/);
          if (m) hashes.push(m[0]);
        }
      });
      const uniq = [...new Set(hashes)];
      if (uniq.length) return uniq[0];
    }
    await sleep(4000 * (i + 1));
  }
  return null;
}

async function waitNewTx(address, oldHash, label){
  console.log(`[TX] Waiting for ${label} tx on Basescan...`);
  for (let i=1;i<=12;i++){
    const h = await latestBaseTx(address, 1).catch(() => null);
    if (h && h !== oldHash) {
      console.log(`[TX] ${label}: ${h}`);
      return h;
    }
    console.log(`[TX] not visible yet (${i}/12)`);
    await sleep(5000);
  }
  return null;
}

async function api(page, url, opts={}){
  const out = await page.evaluate(async ({ url, opts }) => {
    const res = await fetch(url, {
      credentials: 'include',
      ...opts,
      headers: { 'content-type': 'application/json', ...(opts.headers || {}) },
    });
    const text = await res.text();
    let data = text;
    try { data = JSON.parse(text); } catch {}
    return { ok: res.ok, status: res.status, data, text };
  }, { url, opts });
  if (!out.ok) throw new Error(`${opts.method || 'GET'} ${url} ${out.status}: ${String(out.text).slice(0,300)}`);
  return out.data;
}

async function clickFirst(page, selectors, timeout=15000){
  for (const sel of selectors){
    try {
      const loc = page.locator(sel).first();
      await loc.waitFor({ state: 'visible', timeout: Math.max(1000, Math.floor(timeout / selectors.length)) });
      await loc.click({ timeout: 5000 });
      return sel;
    } catch {}
  }
  throw new Error(`No clickable selector found: ${selectors.join(' | ')}`);
}

async function fillFirst(page, selectors, value, timeout=15000){
  for (const sel of selectors){
    try {
      const loc = page.locator(sel).first();
      await loc.waitFor({ state: 'visible', timeout: Math.max(1000, Math.floor(timeout / selectors.length)) });
      await loc.fill(value, { timeout: 5000 });
      return sel;
    } catch {}
  }
  throw new Error(`No input selector found: ${selectors.join(' | ')}`);
}

async function autoCreateAgentUI(page, context, name, traits){
  console.log('[UI] Driving create-agent deterministic flow.');
  const main = () => context.pages().find(p => p.url().includes('doppel.fun')) || page;
  const p = main();
  const clickNext = async (label='Next') => {
    for (const sel of [
      `button:not([disabled]):has-text("${label}")`,
      `[role="button"]:has-text("${label}")`,
      `text=${label}`,
      'button:not([disabled]).bg-white',
      'button:not([disabled]).bg-black',
      'button:not([disabled])'
    ]) {
      const loc = p.locator(sel);
      const count = await loc.count().catch(() => 0);
      for (let i = Math.max(0, count - 1); i >= 0; i--) {
        if (await loc.nth(i).click({ timeout: 900 }).then(() => true).catch(() => false)) { await sleep(350); return true; }
      }
    }
    await p.keyboard.press('Enter').catch(() => {});
    await sleep(350);
    return false;
  };

  for (let i=1; i<=4; i++) {
    await clickNext('Next');
    console.log(`[UI] Next ${i}/4`);
  }

  await p.locator('input[name="agentName"], input[placeholder*="name" i], input[type="text"], textarea').first().fill(name, { timeout: 3000 }).catch(() => {});
  console.log(`[UI] Name ${name}`);
  await clickNext('Next');

  const clickExactOption = async (text, label) => {
    for (let pass=0; pass<10; pass++) {
      const candidates = [
        `button:has-text("${text}")`,
        `[role="button"]:has-text("${text}")`,
        `label:has-text("${text}")`,
        `text="${text}"`,
      ];
      for (const sel of candidates) {
        const loc = p.locator(sel).first();
        if (!(await loc.isVisible().catch(() => false))) continue;
        const txt = ((await loc.innerText({ timeout: 300 }).catch(() => text)) || text).trim();
        if (/^log out$/i.test(txt)) continue;
        await loc.scrollIntoViewIfNeeded().catch(() => {});
        if (await loc.click({ timeout: 1000, force: true }).then(() => true).catch(() => false)) {
          console.log(`[UI] ${label}: ${text}`);
          await sleep(600);
          return true;
        }
      }
      await sleep(500);
    }
    console.log(`[UI] ${label} not found: ${text}`);
    return false;
  };

  const waitForOptionPage = async (wanted, label) => {
    for (let i=0; i<20; i++) {
      const text = (await p.evaluate(() => document.body?.innerText || '').catch(() => '')).toLowerCase();
      if (wanted.some(w => text.includes(String(w).toLowerCase()))) return true;
      console.log(`[UI] Waiting for ${label} page...`);
      await sleep(700);
    }
    return false;
  };

  const personalitiesWanted = traits.slice(0, 2);
  const interestsWanted = traits.slice(2, 4);
  await waitForOptionPage([...personalitiesWanted, ...interestsWanted, 'Music','Gaming','Art','Science','History','Technology','Literature'], 'personality/interests');
  console.log(`[UI] Personality & interests same page. Personalities=${personalitiesWanted.join(', ')} Interests=${interestsWanted.join(', ')}`);
  for (const item of personalitiesWanted) await clickExactOption(item, 'personality');
  await sleep(800);

  const clickRandomOptions = async (targetCount, label) => {
    let clicked = 0;
    for (let pass=0; pass<5 && clicked<targetCount; pass++) {
      const loc = p.locator('button:not([disabled]), [role="button"], label, div[class*="cursor"], div[class*="card"]');
      const count = await loc.count().catch(() => 0);
      const items = [];
      for (let i=0; i<count; i++) {
        const el = loc.nth(i);
        const txt = ((await el.innerText({ timeout: 300 }).catch(() => '')) || '').trim();
        if (!txt || /^log out$/i.test(txt) || /^(back|next|continue|create|finish|sign in)$/i.test(txt)) continue;
        const box = await el.boundingBox().catch(() => null);
        if (!box || box.width < 20 || box.height < 20) continue;
        items.push({ el, txt });
      }
      for (const item of pick(items, Math.max(0, targetCount-clicked))) {
        if (await item.el.click({ timeout: 1000, force: true }).then(() => true).catch(() => false)) {
          clicked++;
          console.log(`[UI] ${label} random ${clicked}/${targetCount}: ${item.txt.slice(0,80)}`);
          await sleep(600);
        }
      }
      if (clicked<targetCount) await sleep(700);
    }
    return clicked;
  };

  console.log(`[UI] Interests: choosing random options, preferred=${interestsWanted.join(', ')}`);
  let interestClicked = 0;
  for (const item of interestsWanted) {
    let ok = await clickExactOption(item, 'interest');
    if (!ok) ok = await clickExactOption(item[0]?.toUpperCase() + item.slice(1), 'interest');
    if (ok) interestClicked++;
  }
  if (interestClicked < 2) interestClicked += await clickRandomOptions(2 - interestClicked, 'interest');
  console.log(`[UI] Interests selected=${interestClicked}/2`);
  await sleep(1000);
  await clickNext('Next');
  await sleep(3000);

  for (let i=0; i<20; i++) {
    const hasCreate = await p.locator('button:has-text("Create Agent"), [role="button"]:has-text("Create Agent"), button:has-text("Create"), [role="button"]:has-text("Create")').first().isVisible({ timeout: 300 }).catch(() => false);
    if (hasCreate) { console.log('[UI] Create step visible.'); break; }
    await clickNext('Next');
    await sleep(800);
  }

  let clickedCreate = false;
  for (let i=0; i<60 && !clickedCreate; i++) {
    for (const sel of ['button:has-text("Create Agent")', '[role="button"]:has-text("Create Agent")', 'button:has-text("Create")', '[role="button"]:has-text("Create")']) {
      clickedCreate = await p.locator(sel).first().click({ timeout: 700 }).then(() => true).catch(() => false);
      if (clickedCreate) break;
    }
    if (!clickedCreate) await sleep(500);
  }
  console.log(`[UI] Create Agent clicked=${clickedCreate}`);

  for (let step=0; step<180; step++){
    const cur = main();
    const m = cur.url().match(/\/agent\/([0-9a-f-]{36})/i);
    if (m) return m[1];

    for (const pop of context.pages().filter(x => x.url().includes('keys.coinbase.com'))) {
      const clicked = await clickFirst(pop, [
        'button:has-text("Confirm")', '[role="button"]:has-text("Confirm")',
        'button:has-text("Continue")', '[role="button"]:has-text("Continue")',
        'button:has-text("Sign")', '[role="button"]:has-text("Sign")',
        'button:has-text("Approve")', '[role="button"]:has-text("Approve")'
      ], 800).catch(() => false);
      if (clicked) console.log('[UI] Coinbase confirm/sign clicked.');
    }

    for (const sel of ['button:has-text("Finish Setup")', '[role="button"]:has-text("Finish Setup")', 'button:has-text("Finish")', '[role="button"]:has-text("Finish")']) {
      const clicked = await cur.locator(sel).first().click({ timeout: 400 }).then(() => true).catch(() => false);
      if (clicked) { console.log('[UI] Finish Setup clicked.'); break; }
    }

    await sleep(1000);
  }
  throw new Error('UI create did not reach /agent/<id>');
}

async function autoCoinbaseLogin(page, context, email, rl){
  console.log('[LOGIN] Finding Coinbase/Base Account button...');
  let popupPromise = context.waitForEvent('page', { timeout: 60000 }).catch(() => null);
  const loginSelectors = [
    'button:has-text("Open Doppel Build")', '[role="button"]:has-text("Open Doppel Build")',
    'button:has-text("Coinbase")', '[role="button"]:has-text("Coinbase")',
    'button:has-text("Base Account")', '[role="button"]:has-text("Base Account")',
    'button:has-text("Base")', '[role="button"]:has-text("Base")',
    'button:has-text("Sign in")', 'button:has-text("Sign In")',
    '[role="button"]:has-text("Sign in")', '[role="button"]:has-text("Sign In")',
    'button:has-text("Connect")', '[role="button"]:has-text("Connect")',
    'button:has-text("Continue")', '[role="button"]:has-text("Continue")',
    'text=/Coinbase/i', 'text=/Base Account/i', 'text=/Sign In/i', 'text=/Connect/i'
  ];

  let popup = null;
  const isCoinbasePopup = p => {
    const u = p?.url?.() || '';
    return u.includes('keys.coinbase.com') || u.includes('coinbase.com') || u.startsWith('chrome-error://');
  };
  const badPopups = new WeakSet();
  for (let i = 0; i < 45 && !popup; i++) {
    popup = context.pages().find(p => isCoinbasePopup(p) && !badPopups.has(p)) || null;
    if (popup?.url().startsWith('chrome-error://')) {
      console.log('[LOGIN] Ignoring failed Coinbase popup: chrome-error://chromewebdata/');
      badPopups.add(popup);
      await popup.close().catch(() => {});
      popup = null;
    }
    if (popup?.url().includes('coinbase.com')) break;
    for (const sel of loginSelectors) {
      const clicked = await page.locator(sel).first().click({ timeout: 500, force: true }).then(() => true).catch(() => false);
      if (clicked) {
        console.log(`[LOGIN] Clicked login selector: ${sel}`);
        await sleep(1500);
        break;
      }
    }
    const candidate = context.pages().find(p => isCoinbasePopup(p) && !badPopups.has(p)) || await Promise.race([popupPromise, sleep(100).then(() => null)]);
    if (candidate?.url().startsWith('chrome-error://')) {
      console.log('[LOGIN] Coinbase popup opened as Chrome error. Retrying click; proxy/browser could not load Coinbase.');
      badPopups.add(candidate);
      await candidate.close().catch(() => {});
      popupPromise = context.waitForEvent('page', { timeout: 60000 }).catch(() => null);
      popup = null;
    } else {
      popup = candidate;
    }
    if (!popup) await sleep(1000);
  }

  if (!popup || !popup.url().includes('coinbase.com')) {
    console.log('[LOGIN] Coinbase popup did not open after auto-click attempts.');
  }
  if (!popup) {
    console.log('[LOGIN] Coinbase popup did not open; checking if already logged in on Doppel...');
    try {
      const ok = await page.evaluate(async () => {
        const r = await fetch('/api/accounts/me', { credentials: 'include' });
        return r.ok;
      });
      if (ok) {
        console.log('[LOGIN] Already authenticated on Doppel; skipping Coinbase popup.');
        return;
      }
    } catch {}
    throw new Error('Coinbase popup did not open. Most common cause on AWS: the selected proxy lets curl pass but Chrome cannot tunnel to Coinbase. Try another proxy.');
  }
  await popup.waitForLoadState('domcontentloaded').catch(() => {});
  await popup.waitForTimeout(5000).catch(() => {});
  console.log(`[LOGIN] Coinbase page: ${popup.url()}`);
  if (popup.url().startsWith('chrome-error://')) {
    throw new Error('Coinbase opened Chrome error page. Proxy/browser cannot reach Coinbase; remove this proxy or try another proxy line.');
  }

  if (!popup.url().includes('keys.coinbase.com') && popup !== page) await popup.bringToFront().catch(() => {});

  // Coinbase first shows an onboarding screen with Sign in / Create account.
  await clickFirst(popup, [
    'button:has-text("Sign in")',
    'button:has-text("Sign In")',
    '[role="button"]:has-text("Sign in")',
    '[role="button"]:has-text("Sign In")',
  ], 12000).catch(() => {});
  await popup.waitForTimeout(3000).catch(() => {});

  const popupUrl = popup.url();
  const alreadyAuthed = /\/sign\/|\/connect/.test(popupUrl);
  if (!alreadyAuthed) {
    console.log('[LOGIN] Filling email...');
    await fillFirst(popup, [
      'input[type="email"]',
      'input[name="email"]',
      'input[autocomplete="email"]',
      'input[placeholder*="email" i]',
      'input[inputmode="email"]',
      'input[type="text"]',
    ], email, 30000);
    await clickFirst(popup, [
      'button[type="submit"]',
      'button:has-text("Continue")',
      'button:has-text("Submit")',
      'button:has-text("Next")',
      '[role="button"]:has-text("Continue")',
    ], 15000);
    const prompt = promptSync({ sigint: true });

const rawOtp = prompt('OTP code: ') || '';

console.log('[DEBUG] raw OTP =', JSON.stringify(rawOtp));

const code = rawOtp.trim();

console.log('[DEBUG] parsed OTP =', code);

await popup.bringToFront().catch(() => {});

if (!/^\d{6}$/.test(code)) {
  console.log('[LOGIN] Invalid OTP.');
  return;
}

const otpSelectors = [
  'input[autocomplete="one-time-code"]',
  'input[inputmode="numeric"]',
  'input[type="tel"]'
].join(', ');

const otpBoxes = popup.locator(otpSelectors);

const count = await otpBoxes.count();

console.log(`[LOGIN] OTP inputs found=${count}`);

if (count >= 6) {

  for (let i = 0; i < 6; i++) {

    const box = otpBoxes.nth(i);

    await box.click();

    // use pressSequentially instead of fill/type
    await box.pressSequentially(code[i], {
      delay: 100
    });

    await popup.waitForTimeout(150);
  }

  console.log('[LOGIN] OTP entered.');
}
    await popup.waitForTimeout(1500).catch(() => {});
    await popup.keyboard.press('Enter').catch(() => {});
    await popup.waitForTimeout(1000).catch(() => {});
    await clickFirst(popup, [
      'button:not([disabled]):has-text("Continue")',
      'button:not([disabled]):has-text("Verify")',
      'button:not([disabled])[type="submit"]',
      'button:not([disabled]):has-text("Submit")',
      '[role="button"]:has-text("Continue")',
      '[role="button"]:has-text("Verify")',
    ], 20000).catch(async () => {
      await popup.keyboard.press('Enter').catch(() => {});
      await popup.waitForTimeout(1000).catch(() => {});
    });
  } else {
    console.log('[LOGIN] Coinbase already authenticated; skipping email/OTP.');
  }

  console.log('[LOGIN] Waiting for Doppel session...');
  let lastState = '';
  for (let i=0;i<90;i++){
    // Log visible pages/buttons so Coinbase/Doppel callback blockers are not blind.
    const state = await Promise.all(context.pages().map(async p => {
      const buttons = await p.evaluate(() => Array.from(document.querySelectorAll('button,[role="button"],a'))
        .map(el => (el.innerText || el.textContent || el.getAttribute('aria-label') || '').trim())
        .filter(Boolean)
        .slice(0, 20)).catch(() => []);
      const text = await p.evaluate(() => document.body?.innerText?.slice(0, 500) || '').catch(() => '');
      return `${p.url()} :: buttons=[${buttons.join(' | ')}] :: text=${text.replace(/\s+/g,' ').slice(0,300)}`;
    }));
    const compactState = state.join('\n');
    if (compactState && compactState !== lastState) {
      console.log(`[STATE]\n${compactState}`);
      lastState = compactState;
    }

    // Coinbase may show connect/continue/approve screens after OTP.
    for (const p of context.pages()) {
      if (p.url().includes('keys.coinbase.com')) {
        await clickFirst(p, [
          'button:has-text("I’ll do this later")',
          'button:has-text("I’ll Do This Later")',
          'button:has-text("I\'ll do this later")',
          'button:has-text("I\'ll Do This Later")',
          'button:has-text("I\'ll Do This Later")',
          'button:has-text("I\'ll do this later")',
          'button:has-text("Do this later")',
          'button:has-text("Do This Later")',
          'button:has-text("Skip")',
          'button:has-text("Not now")',
          'button:has-text("Continue")',
          'button:has-text("Connect")',
          'button:has-text("Allow")',
          'button:has-text("Approve")',
          'button:has-text("Confirm sign in")',
          'button:has-text("Confirm Sign In")',
          'button:has-text("Sign in")',
          'button:has-text("Sign In")',
          'button:has-text("Sign")',
          'button:has-text("Confirm")',
          '[role="button"]:has-text("I’ll do this later")',
          '[role="button"]:has-text("I’ll Do This Later")',
          '[role="button"]:has-text("I\'ll do this later")',
          '[role="button"]:has-text("I\'ll Do This Later")',
          '[role="button"]:has-text("Do this later")',
          '[role="button"]:has-text("Do This Later")',
          '[role="button"]:has-text("Skip")',
          '[role="button"]:has-text("Not now")',
          '[role="button"]:has-text("Continue")',
          '[role="button"]:has-text("Connect")',
          '[role="button"]:has-text("Allow")',
          '[role="button"]:has-text("Approve")',
          '[role="button"]:has-text("Confirm sign in")',
          '[role="button"]:has-text("Confirm Sign In")',
          '[role="button"]:has-text("Sign in")',
          '[role="button"]:has-text("Sign In")',
          '[role="button"]:has-text("Sign")',
          '[role="button"]:has-text("Confirm")',
        ], 1500).catch(() => {});
        await p.keyboard.press('Enter').catch(() => {});
      }
    }
    const cookies = await context.cookies(ORIGIN);
    if (cookies.find(c => c.name === 'doppel_session')) return;
    const main = context.pages().find(p => p.url().includes('doppel.fun')) || page;
    try {
      const ok = await main.evaluate(async () => {
        const res = await fetch('/api/care/agents', { credentials: 'include' });
        return res.ok;
      });
      if (ok) return;
    } catch {}
    await sleep(1000);
  }
  throw new Error('Login completed but doppel_session cookie was not found');
}

async function main(){
  const rl = readline.createInterface({ input, output });
  console.log('[START] CloakBrowser Coinbase combined automation.');
  const emailArg = process.argv.find(a => a.startsWith('--email='));
  const email = emailArg ? emailArg.split('=').slice(1).join('=') : await rl.question('Coinbase email: ');

  await fs.mkdir(PROFILE_DIR, { recursive: true });
  console.log(`[BROWSER] Persistent profile slot ${PROFILE_SLOT}: ${PROFILE_DIR}`);
  // ── Load & verify proxy from proxies.txt ────────────────────────────────
  const proxies = loadProxies();
  const proxy   = await pickWorkingProxy(proxies, `slot${PROFILE_SLOT}`);

  const context = await launchPersistentContext({
    userDataDir: PROFILE_DIR,
    headless: false,
    proxy: {
      server:   proxy.server,
      ...(proxy.username ? { username: proxy.username, password: proxy.password } : {}),
    },
    args: [
      '--disable-setuid-sandbox',
      '--use-gl=swiftshader',
      '--window-size=1366,768',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-background-networking',
      '--dns-servers=1.1.1.1,1.0.0.1',
      '--enable-features=DnsOverHttps',
      '--dns-over-https-templates=https://cloudflare-dns.com/dns-query',
    ],
    locale: 'en-US',
    timezone: 'America/New_York',
    viewport: { width: 1366, height: 768 },
    userAgent: UA,
  });

  // ── Block media & heavy resources to save bandwidth/CPU ─────────────────
  const BLOCKED_RES  = new Set(['media', 'websocket']);
  const BLOCKED_EXTS = /\.(mp4|mp3|webm|ogg|avi|mov|flv|mkv|wav|aac|m4a|m3u8|ts)(\?.*)?$/i;
  await context.route('**/*', route => {
    const type = route.request().resourceType();
    const url  = route.request().url();
    if (BLOCKED_RES.has(type) || BLOCKED_EXTS.test(url)) return route.abort();
    return route.continue();
  });
  const attachExplore = p => {
    p.on('request', req => logExplore({ type: 'request', url: req.url(), method: req.method(), resourceType: req.resourceType() }));
    p.on('response', async res => {
      const url = res.url();
      await logExplore({ type: 'response', url, status: res.status() });
      if (url.includes('/api/auth/verify')) {
        const headers = await res.allHeaders().catch(() => ({}));
        const sess = sessionFromSetCookie(headers['set-cookie'] || headers['Set-Cookie'] || '');
        if (sess) {
          await saveSession(email, sess);
          console.log('[SESSION] Saved doppel_session from /api/auth/verify Set-Cookie.');
        }
      }
    });
    p.on('console', msg => logExplore({ type: 'console', url: p.url(), level: msg.type(), text: msg.text().slice(0, 1000) }));
    p.on('pageerror', err => logExplore({ type: 'pageerror', url: p.url(), error: String(err.stack || err.message || err).slice(0, 2000) }));
    p.on('close', () => logExplore({ type: 'page-close', url: p.url() }));
  };
  context.pages().forEach(attachExplore);
  context.on('page', attachExplore);
  console.log('[CLEANUP] Start of account. Wiping website data once; preserving browser profile settings.');
  await context.clearCookies().catch(() => {});
  const cleanPage = context.pages()[0] || await context.newPage();
  const cdp = await context.newCDPSession(cleanPage).catch(() => null);
  for (const origin of [
    'https://doppel.fun',
    'https://keys.coinbase.com',
    'https://www.coinbase.com',
    'https://api.wallet.coinbase.com',
    'https://cca-lite.coinbase.com',
    'https://spindl.link'
  ]) {
    await cdp?.send('Storage.clearDataForOrigin', { origin, storageTypes: 'all' }).catch(() => {});
  }
  await cleanPage.goto(ORIGIN, { waitUntil: 'domcontentloaded', timeout: 90000 }).catch(() => {});
  await cleanPage.evaluate(() => {
    try {
      localStorage.clear();
      sessionStorage.clear();
      indexedDB.databases?.().then(dbs => dbs.forEach(db => indexedDB.deleteDatabase(db.name))).catch(() => {});
      caches?.keys?.().then(keys => keys.forEach(k => caches.delete(k))).catch(() => {});
    } catch {}
  }).catch(() => {});
  await context.addInitScript(({ dev, spdl }) => {
    try {
      if (location.hostname === 'doppel.fun') {
        if (!localStorage.getItem('device_id')) localStorage.setItem('device_id', dev);
        if (!localStorage.getItem('spdl_pid')) localStorage.setItem('spdl_pid', spdl);
      }
    } catch {}
  }, { dev: deviceId(), spdl: spdlPid() });
  await context.addInitScript(() => {
    try {
      const origPost = window.postMessage;
      window.postMessage = function(message, targetOrigin, transfer) {
        console.log('[PM_SEND]', JSON.stringify({ targetOrigin, message }).slice(0, 1000));
        return origPost.call(this, message, targetOrigin, transfer);
      };
      window.addEventListener('message', ev => {
        console.log('[PM_RECV]', JSON.stringify({ origin: ev.origin, data: ev.data }).slice(0, 1000));
      });
    } catch (e) { console.log('[PM_HOOK_ERR]', String(e)); }
  });
  const page = context.pages()[0] || await context.newPage();
  await page.goto(ORIGIN, { waitUntil: 'domcontentloaded', timeout: 90000 });
  console.log('[CLEANUP] Start wipe done for Doppel only. No more wiping until current account finishes.');
  await autoCoinbaseLogin(page, context, email.trim(), rl);

  const cookies = await context.cookies(ORIGIN);
  const sess = cookies.find(c => c.name === 'doppel_session')?.value;
  if (sess) await saveSession(email.trim(), sess);

  let me = null;
  try { me = await api(page, '/api/accounts/me'); } catch {}
  const allCookies = await context.cookies(ORIGIN);
  const fullCookie = allCookies.map(c => `${c.name}=${c.value}`).join('; ');
  const { exp: cookieExp } = expiryFields(allCookies);
  await saveCookieHeader(email.trim(), fullCookie, cookieExp);
  const address = me?.walletAddress || me?.address;
  if (!address) throw new Error('Could not find wallet address after login');
  console.log(`[ACCOUNT] ${address}`);
  if (CREATE_ACCOUNT_ONLY) {
    const row = { type: 'coinbase-created-account', email: email.trim(), address, cookie: fullCookie };
    await upsertJsonlById(COINBASE_CREATED_ACCOUNT_FILE, email.trim(), row);
    console.log(`[SAVE] Created account only: ${email.trim()} ${address} -> ${COINBASE_CREATED_ACCOUNT_FILE}`);
    await context.close().catch(() => {});
    console.log('[BROWSER] Closed before agent creation.');
    return;
  }

  if (RENEW_COOKIES_ONLY) {
    let agents = await api(page, '/api/care/agents').catch(() => ({ agents: [] }));
    let agent = (agents.agents || [])[0];
    const agentId = agentIdOf(agent) || null;
    await upsertJsonlById(COINBASE_ACCOUNT_FILE, email.trim(), { type: 'coinbase', email: email.trim(), address, cookie: fullCookie, agentId });
    console.log(`[SAVE] Renewed cookies: ${email.trim()} ${address} agent=${agentId || 'none'} -> ${COINBASE_ACCOUNT_FILE}`);
    await context.close().catch(() => {});
    console.log('[BROWSER] Closed after cookie renewal.');
    return;
  }

  let agents = await api(page, '/api/care/agents');
  let agent = (agents.agents || [])[0];
  let created = false;

  if (!agent) {
    const name = randomName();
    const traits = [...pick(TRAITS,2), ...pick(TOPICS,2)];
    console.log(`[NEW] Generating soul: ${name} ${traits.join(', ')}`);
    const soulData = await api(page, '/api/accounts/me/generate-soul', { method: 'POST', body: JSON.stringify({ agentName: name, traits }) });
    const soul = soulData.soul || soulData.generatedSoul || JSON.stringify(soulData);

    console.log('[ACTION] Create the agent in the browser UI using locators. Do not use API/Basescan.');
    console.log(`[ACTION] Suggested agent: ${name} traits=${traits.join(', ')}`);
    const uiAgentId = await autoCreateAgentUI(page, context, name, traits);
    agent = { id: uiAgentId, agentId: uiAgentId, source: 'browser-ui-locator' };
    created = true;
  }

  const agentId = agentIdOf(agent) || agent?.id;
  if (!agentId) throw new Error('No agent id found');
  console.log(`[AGENT] ${agentId} created=${created}`);
  if (page.url().includes('/agent/')) {
    const freshCookies = await context.cookies(ORIGIN);
    const freshCookie = freshCookies.map(c => `${c.name}=${c.value}`).join('; ');
    const { exp: freshExp } = expiryFields(freshCookies);
    await saveCookieHeader(email.trim(), freshCookie, freshExp);
    await upsertJsonlById(COINBASE_ACCOUNT_FILE, email.trim(), { type: 'coinbase', email: email.trim(), address, cookie: freshCookie, agentId });
    console.log(`[SAVE] Agent page reached. Saved cookies for ${agentId}.`);
    await context.close().catch(() => {});
    console.log('[BROWSER] Closed after reaching agent page.');
    return;
  }

  const action = await api(page, '/api/care/action', { method: 'POST', body: JSON.stringify({ agentId, action: 'praise' }) }).catch(e => ({ error: e.message }));
  let prep = null;
  let checkTx = null;
  let checkin = { skipped: true, reason: 'disabled; pass --checkin to enable' };
  if (DO_CHECKIN) {
    const beforeCheckin = await latestBaseTx(address, 2).catch(() => null);
    try {
      prep = await api(page, '/api/care/check-in/prepare', { method: 'POST', body: JSON.stringify({ agentId }) });
      checkTx = txOf(prep);
      if (!checkTx) {
        console.log('[ACTION] If Coinbase popup appears, confirm the check-in transaction.');
        await rl.question('Press Enter after transaction is confirmed: ');
        checkTx = await waitNewTx(address, beforeCheckin, 'check-in');
      }
      checkin = checkTx
        ? await api(page, '/api/care/check-in/confirm', { method: 'POST', body: JSON.stringify({ agentId, txHash: checkTx }) })
        : { skipped: true, reason: 'No check-in txHash found' };
    } catch (e) {
      const msg = e.message || String(e);
      if (msg.includes('409')) {
        console.log('[CHECKIN] Not available or already done today. Skipping.');
        prep = { skipped: true, status: 409, reason: 'check-in not available or already done today' };
        checkin = prep;
      } else {
        throw e;
      }
    }
  }

  const row = { type: 'coinbase-cloak', email: email.trim(), address, cookie: fullCookie, agent, created, action, prepare: prep, checkTx, checkin };
  await upsertJsonlById(COINBASE_ACCOUNT_FILE, email.trim(), { type: 'coinbase', email: email.trim(), address, cookie: fullCookie, agentId });
  await append(row);
  console.log(`[DONE] Saved ${OUT}`);

  await context.close().catch(() => {});
  console.log('[BROWSER] Closed. No end wipe; next run wipes at start.');
}

main().catch(e => { console.error('[FATAL]', e.stack || e.message); process.exit(1); });

