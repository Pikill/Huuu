const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const CLOUDFLARE_DOH =
  'https://chrome.cloudflare-dns.com/dns-query';

rl.question('Enter profile folder name: ', (folderName) => {
  const localStatePath = `./${folderName}/Local State`;

  try {
    // Read file
    let data = fs.readFileSync(localStatePath, 'utf8');

    // If dns_over_https already exists
    if (data.includes('"dns_over_https"')) {

      // Check if it's already using Cloudflare
      if (data.includes(CLOUDFLARE_DOH)) {
        console.log('Cloudflare DNS-over-HTTPS already configured.');
      } else {
        console.log('dns_over_https exists but is NOT Cloudflare. No changes made.');
      }

    } else {
      // Insert dns_over_https before hardware_acceleration_mode_previous
      data = data.replace(
        '}},"hardware_acceleration_mode_previous"',
        `}},"dns_over_https":{"mode":"secure","templates":"${CLOUDFLARE_DOH}"},"hardware_acceleration_mode_previous"`
      );

      // Save back
      fs.writeFileSync(localStatePath, data, 'utf8');

      console.log('Cloudflare DNS-over-HTTPS added successfully.');
    }

  } catch (err) {
    console.error('Error:', err.message);
  }

  rl.close();
});