#!/usr/bin/env node
import fs from 'fs/promises';
import path from 'path';

const ROOT = process.cwd();
const OUT = path.join(ROOT, 'all_addresses.txt');
const SOURCES = [
  path.join(ROOT, 'dopcbaccounts.jsonl'),
  path.join(ROOT, 'dopcbcreatedaccounts.jsonl'),
  path.join(ROOT, 'created_accounts.jsonl'),
  path.join(ROOT, 'accounts.jsonl'),
  path.join(ROOT, 'explore_coinbase.jsonl'),
  path.join(ROOT, 'quest_results.jsonl'),
];

const addrRe = /0x[a-fA-F0-9]{40}/g;
const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
const rows = new Map();

function add(email, address){
  if (!address) return;
  const addr = address.toLowerCase();
  const old = rows.get(addr) || { email: '', address: addr };
  if (email && !old.email) old.email = email.toLowerCase();
  rows.set(addr, old);
}

function scanText(txt){
  const emails = [...txt.matchAll(emailRe)].map(m => m[0].toLowerCase());
  const addrs = [...txt.matchAll(addrRe)].map(m => m[0].toLowerCase());
  const nearestEmail = emails[0] || '';
  for (const addr of addrs) add(nearestEmail, addr);
}

function scanJsonLine(line){
  let obj;
  try { obj = JSON.parse(line); } catch { scanText(line); return; }
  const text = JSON.stringify(obj);
  const addrs = [...text.matchAll(addrRe)].map(m => m[0].toLowerCase());
  const emails = [...text.matchAll(emailRe)].map(m => m[0].toLowerCase());
  const email = obj.email || obj.id?.includes?.('@') && obj.id || emails[0] || '';
  for (const addr of addrs) add(String(email || '').toLowerCase(), addr);
}

async function scanFile(file){
  let txt;
  try { txt = await fs.readFile(file, 'utf8'); }
  catch(e){ if (e.code === 'ENOENT') return; throw e; }
  for (const line of txt.split(/\r?\n/).filter(Boolean)) scanJsonLine(line);
}

async function main(){
  for (const file of SOURCES) await scanFile(file);
  const out = ['email|address', ...[...rows.values()].sort((a,b) => (a.email+a.address).localeCompare(b.email+b.address)).map(r => `${r.email}|${r.address}`)];
  await fs.writeFile(OUT, out.join('\n') + '\n');
  console.log(`Exported ${rows.size} email/address rows -> ${OUT}`);
}

main().catch(e => { console.error('[FATAL]', e.stack || e.message); process.exit(1); });
