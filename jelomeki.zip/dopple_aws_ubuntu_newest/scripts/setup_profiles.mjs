#!/usr/bin/env node
import fs from 'fs/promises';
import path from 'path';

const ROOT = process.cwd();
for (let i = 1; i <= 5; i++) {
  const dir = path.join(ROOT, `profileS${i}`);
  await fs.mkdir(dir, { recursive: true });
}
console.log('Prepared persistent profiles: profileS1..profileS5');
